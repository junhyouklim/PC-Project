#include "Proxy_Server.h"

int main(void)
{
    Server serv;

    serv.Server_On();

    return 0;
}